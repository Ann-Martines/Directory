// ������� 6 Directory.cpp: ���������� ����� ����� ��� ����������� ����������.
//

#include "stdafx.h"
#include<conio.h>
#include "Directory.h"




int main()
 {
	try
	{
		Directory direct;
		char ch;
		do
		{
			system("cls");
			std::cout << std::ends << "Menu:" << std::endl;
			std::cout << "1 - Creations of the catalog on the specified way;" << std::endl;
			std::cout << "2 - Creations of the file in the specified catalog;" << std::endl;  
			std::cout << "3 - Removals of the file in the specified catalog" << std::endl;  
			std::cout << "ESC - exit;" << std::endl;
			ch = _getch();
			switch (ch)
			{
			case '1': system("cls");
				std::cin >> direct;
				direct.�reateCatalog();
				system("pause");
				break;
			case '2': system("cls");
				std::cin >> direct;
				direct.�reateFile();
				system("pause");
				break;
			case '3': system("cls");
				std::cin >> direct;
				direct.RemoveFile();
				system("pause");
				break;
			}
		} while (ch != 27);
	}
	catch (const std::exception &ex)
	{
		std::cout << ex.what() << std::endl;
	}
	catch (...)
	{
		std::cout << "Unhandled exception" << std::endl;
	}

    return 0;
}
