#include "stdafx.h"
#include "Directory.h"




std::istream & operator >> (std::istream &is, Directory &p)
{
	std::cout << "Enter way:" << std::ends;
	std::string way;
	is >> way;
	p.Way = way;
	return is;
}


void Directory::�reateCatalog()										//Method for creation of the catalog
{
	if (_mkdir(Way.c_str()) == 0)
	{
		std::cout << "The catalog is created" << std::endl;
	}
	else
		throw std::invalid_argument("Error! The catalog isn't created");
}
void Directory::�reateFile()										//Method for creation of the file
{
	std::ofstream f(Way);
	if (f)
	{
		std::cout << "The file is created" << std::endl;
	}
	else
		throw std::invalid_argument("Error! The file isn't created");
}
void Directory::RemoveFile()										//Method for removal of the file
{
	if (remove(Way.c_str()) == 0)
	{
		std::cout << "The file is removed" << std::endl;
	}
	else
		throw std::invalid_argument("Error! The file isn't removed");
}