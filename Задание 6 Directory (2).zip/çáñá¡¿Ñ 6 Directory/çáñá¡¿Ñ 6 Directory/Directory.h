#pragma once
#include<string>
#include <direct.h>
#include <fstream>
#include<iostream>
class Directory
{
	std::string Way;
public:
	Directory() = default;
	~Directory() = default;

	friend std::istream & operator >> (std::istream &, Directory &);	//data entry

	void �reateCatalog();												//Method for creation of the catalog
	void �reateFile();													//Method for creation of the file
	void RemoveFile();													//Method for removal of the file
};

